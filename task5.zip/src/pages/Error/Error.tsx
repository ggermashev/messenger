import React from 'react';

const Error = () => {
    return (
        <div>
           error
        </div>
    );
};

export default Error;